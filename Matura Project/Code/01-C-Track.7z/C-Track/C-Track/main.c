#define F_CPU 1000000


#include <avr/io.h>
#include <util/delay.h>

#include "serial.h"
#include "lora.h"
#include "SD/ff.h"


FATFS FatFs;		/* FatFs work area needed for each volume */
FIL Fil;			/* File object needed for each open file */



int main (void)
{
	UINT bw;
	FRESULT fr;

	// Initialize Serial communication
	spi_init();
	f_mount(&FatFs, "", 0); // mount the file system
	
	_delay_ms(100);
	
	uint8_t buff[] = "Hello World!";
	lora_init();
	lora_putd(buff, 13);


	fr = f_open(&Fil, "newfile.txt", FA_WRITE | FA_CREATE_ALWAYS);	// Create a file
	
	if (fr == FR_OK)
	{
		f_printf(&Fil, "Hello World!\r\n");
		fr = f_close(&Fil);
		
		if (fr == FR_OK && bw == 14)
		{
		}
	}
	
	for (;;) ;
}


