#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>

double convertToDecimalDegrees(float coordinate, char dir) {
    double degrees, minutes;
    int r = 1;

    degrees = (int)(coordinate / 100);
    minutes = fmod(coordinate, 100.0);
    if (dir == 'W' || dir == 'S') r = -1;

    return (degrees + minutes / 60.0) * r;
}

int main()
{
    char day[3];
    char month[3];
    char year[3];

    char hour[3];
    char minutes[3];
    char seconds[3];

    char latDir, lngDir;
    double lat, lng;
    char valid;
    
    const char* str = "$GNRMC,143954.321,V,4749.2698,N,01302.6803,E,0.08,159.09,201223,,,A*74";

    if (11 != sscanf(str, "$GNRMC,%2s%2s%2s.%*d,%c,%lf,%c,%lf,%c,%*f,%*f,%2s%2s%2s", hour, minutes, seconds, &valid, &lat, &latDir, &lng, &lngDir, day, month, year) && valid == 'A')
    {
        return 1;
    }

    lat = convertToDecimalDegrees(lat, latDir);
    lng = convertToDecimalDegrees(lng, lngDir);


    printf("datetime: %s-%s-%s %s:%s:%s\n", year,month,day,hour,minutes,seconds);
    printf("%s\n", valid == 'A'? "valid" : "invalid");
    printf("lat:%c %lf\n", latDir, lat);
    printf("lng:%c %lf\n", lngDir, lng);

    //printf("%s,%s,%.6lf%c,%.6lf%c\r\n", date, time, latitude, latitudeDir, longitude, longitudeDir);

    return 0;
}