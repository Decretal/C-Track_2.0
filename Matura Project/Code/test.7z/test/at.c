#include <string.h>
#include <stdio.h>
#include <stdlib.h>

int main()
{
    const char* a = "49.2698";
    float f = atof(a);
    f /= 60;
    printf("%f", 47.00000f + f);
    return 0;
}