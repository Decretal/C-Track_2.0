#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>

union FloatToBytes {
    float floatValue;
    int byteValue[sizeof(float)];
};

typedef struct Point
{
    float lat, lng;

    char day, month, year;
    char hour, minutes, seconds;
} Point;

inline char convertTwo(const char* str)
{
    return 10 * (str[0] - '0') + (str[1] - '0');
}

int parseRMC(const char* str, Point* p)
{
    while (*str != ',') str++;
    if (str[1] == ',') return 0;
    str++;

    /*
            parse time information
    */
    p->hour =  convertTwo(str);
    str += 2;
    p->minutes = convertTwo(str);
    str += 2;
    p->seconds = convertTwo(str);
    str += 7;

    // check if data is valid
    if (*str != 'A')
    {
        return 0;
    }
    else
    {
        str += 2;
    }

    /*
            parse localization information
    */
    float tmp;
    int c = 10;

    p->lat = 10 * (str[0] - '0') + (str[1] - '0');
    str += 2;

    tmp = 10 * (str[0] - '0') + (str[1] - '0');
    str += 3;
       
    while (*str != ',')
    {
        tmp += (float)(*str - '0') / (float)c;
        c *= 10;
        str++;
    }

    p->lat += tmp / 60;

    str++;
    if (*str == 'S') p->lat *= -1;
    str+=2;



    tmp = 0; c = 10;
    p->lng = 100 * (str[0] - '0') + 10 * (str[1] - '0') + (str[2] - '0');
    str += 2;

    tmp = 10 * (str[0] - '0') + (str[1] - '0');
    str += 3;
    
    while (*str != ',')
    {
        tmp += (float)(*str - '0') / (float)c;
        c *= 10;
        str++;
    }

    p->lng += tmp / 60;

    str++;
    if (*str == 'W') p->lng *= -1;
    str+=2;
    
    while (*str != ',') str++;
    str++;
    while (*str != ',') str++;
    str++;

    /*
        Parse time information
    */

    p->day = convertTwo(str);
    str+=2;

    p->month = convertTwo(str);
    str+=2;

    p->year = convertTwo(str);
    str+=2;

    return 1;
}

int main()
{
    const char* str = "$GNRMC,143954.321,A,4749.2698,N,01302.6803,E,0.08,159.09,201223,,,A*74";

    Point p;

    if(parseRMC(str, &p))
    {
        printf("%d/%d/%d\n", p.hour, p.minutes, p.seconds);
        printf("%f %f\n", p.lat, p.lng);
        printf("%d/%d/%d", p.day, p.month, p.year);
    }
    else
    {
        printf("Not valid");
    }
}